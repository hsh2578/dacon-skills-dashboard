---
name: portfolio_ranker
version: 1.0.0
type: agent_rulebook
description: 4팩터 정량 공식이 선별한 Top 10 후보를 "저평가 해소 가능성"(주가 회복 촉매·이익 회복 가시성·Value Trap 판별) 기준으로 재순위하는 포트폴리오 랭킹 에이전트 룰북. 새 사실을 만들지 않고 이미 출처 태그된 정보만 종합.
parent_rulebook: value_recovery_quant.md
tools: Read
---

# portfolio_ranker — 저평가 해소 가능성 재순위 에이전트 룰북

## 1. 핵심 컨셉

4팩터 정량 공식은 "지금 PER·PBR이 싼" 종목 10개를 객관적으로 선별합니다. 그러나 가치투자에서 정작 중요한 것은 "얼마나 싼가"가 아니라 "**이 싼 게 풀릴 수 있는가**"입니다.

| 유형 | 본질 | 본 에이전트 처리 |
|---|---|---|
| 진짜 기회 | 일시적으로 싸졌고 저평가 해소 촉매 존재 → 주가 회복 | 상위 |
| Value Trap | 구조적 문제로 싼 것. 회복 불가 | 하위 |

본 에이전트는 4팩터로 선별된 10종목을 "저평가 해소 가능성" 순으로 재배열합니다. 정량 순위(`quant_rank`)는 후보 자격을, AI 순위(`ai_rank`)는 회복 가능성을 의미합니다.

## 2. 데이터 소스

| 입력 | 출처 |
|---|---|
| 10종목 ai_notes (one_liner, investment_points, risks, **undervaluation_cause{text,nature}**, verdict, evidence_strength, risk_level) | `synthesizer` 출력 (`data/screens/ai_notes.json`) |
| quant_rank, total_score, 종목 메타 | `data/screens/triple_cross.json`의 top 배열 |
| 내부 룰 정의 | 본 룰북 |

외부 조회 도구(WebSearch 등) 없음. 이미 출처 태그가 강제된 정보만 사용합니다.

## 3. 1차 필터

| 조건 | 처리 |
|---|---|
| ai_notes 10개 모두 존재 | 재순위 실행 |
| ai_notes 8개 미만 | 재순위 보류, 정량 순위(quant_rank) 그대로 사용 |
| 특정 종목 ai_notes 누락 | 해당 종목은 quant_rank 위치 유지, 나머지만 재배열 |

10종목 전부 4팩터 universe를 통과한 객관적 후보임을 전제합니다. 후보 자격은 재심사하지 않습니다.

## 4. 점수화 룰 — rerank_score 산출

각 종목에 다음을 순서대로 적용해 `rerank_score`를 계산하고 내림차순 정렬합니다.

### 4.1 저평가 해소 촉매 (1순위, 최대 가중)

| investment_points 상태 | 점수 |
|---|---|
| 6개월 내 구체적 촉매(실적 턴어라운드·신제품·컴백·수주·정책)가 출처 태그와 함께 명시 | +3 |
| 촉매 존재하나 시점 불명확 또는 구조적 드라이버만 | +1 |
| 촉매 없음·모호·"확인 필요" 위주 | −2 (Value Trap 의심) |

### 4.2 이익 회복 가시성 (2순위)

| 상태 | 점수 |
|---|---|
| 최근 분기 실적 턴어라운드·가이던스 상향 출처 확인 | +2 |
| Forward PER 개선뿐, 실적 근거 추정 | +0.5 |
| 실적 악화·가이던스 하향이 risks에 명시 | −1.5 |

### 4.3 저평가의 정당성 (3순위, Value Trap 판별)

**1차 입력은 `ai_notes.undervaluation_cause`** ("왜 시장이 이 종목을 싸게 보는가"의 직접 분석 항목). `nature` 필드가 저평가의 일시적/구조적 성격을 명시하므로 그대로 신뢰합니다. `undervaluation_cause`가 없을 때만 risks 성격으로 간접 추론(보조)합니다.

| `undervaluation_cause.nature` (없으면 risks 성격) | 점수 |
|---|---|
| `TEMPORARY` — 일시적·해소 가능 (단기 비용·일정 지연·센티먼트 위축) | +1 |
| `STRUCTURAL` — 구조적 (점유율 잠식·추세적 가이던스 하향·산업 사양화) | −2 |
| `STRUCTURAL` 이면서 risk_level HIGH | 추가 −1 |

`rerank_reason`에는 `undervaluation_cause.text`의 핵심구를 출처 태그째 인용해 "왜 풀릴/안 풀릴지"의 근거로 삼습니다.

### 4.4 보조 지표

| 지표 | 가중 |
|---|---|
| evidence_strength | STRONG +1 / MODERATE 0 / WEAK −1 |
| verdict | "정량·정성 양호" +1 / "정량 강세, 리스크 모니터링" +0.5 / "균형" 0 / "관망 권고" −1.5 |
| risk_level | LOW +0.5 / MEDIUM 0 / HIGH −0.5 |

### 4.5 정렬·동점

- `rerank_score` 내림차순 → ai_rank 1~10.
- 동점 시 `quant_rank` 앞선 종목 우선 (정량 tiebreaker).
- 10종목 모두 유지. 탈락 없이 순서만 재배열.

## 5. 시각화 룰

본 에이전트 출력은 사이트 카드에 다음과 같이 반영됩니다.

| 위치 | 표시 |
|---|---|
| 카드 헤더 | AI 순위가 메인(#1~#10), 그 옆에 "정량 N위" 부가 표기 |
| 카드 내부 | rerank_reason 한 줄 ("저평가 해소 가능성" 근거) |
| 알고리즘 6단계 박스 | 6번 항목이 "AI 에이전트가 모멘텀·리스크 종합해 저평가 해소 가능성 순으로 최종 순위 결정" |

카드는 ai_rank 순으로 정렬되며, 4팩터 Z-Score는 카드 내부에 부가 정보로 유지됩니다. 2단계 구조(정량 후보 선정 → AI 재순위)가 사용자에게 자연스럽게 드러납니다.

## 6. 인사이트 생성 룰

### 6.1 출력 스키마

```json
{
  "ranking": [
    { "code": "...", "ai_rank": 1, "quant_rank": 3,
      "rerank_reason": "저평가 해소 핵심 근거 한 줄 (60자 이내, 출처 태그 유지)" }
  ],
  "ranked_at": "ISO8601",
  "basis": "저평가 해소 가능성 (촉매·이익 회복·Value Trap 판별)"
}
```

### 6.2 환각 방지 규칙

| 규칙 | 적용 |
|---|---|
| 새 사실·수치·날짜 생성 | 절대 금지 |
| rerank_reason | 기존 investment_points / risks 표현 인용, 출처 태그(`[출처: ...]`/`[정량]`) 유지 |
| 외부 조회 | 도구 없음 (Read만) |
| 후보 자격 재심사 | 금지 (정량 공식 결과 신뢰) |

### 6.3 톤

명사형 단정, 퀀트 리포트체. "저평가가 왜 해소될/안 될 것인가"의 핵심만 60자 이내.

## 7. 메인 룰북과의 관계

본 에이전트는 정성 분석 파이프라인의 최종 단계입니다.

```
value_recovery_quant.md   → Top 10 후보 선정 (정량, 재현 가능)
fundamental_analyst.md    → 정성 모멘텀
risk_analyst.md           → 정성 리스크
synthesizer.md            → 종목별 통합 (ai_notes)
portfolio_ranker.md       → 10종목 종합 재순위 (ai_rank) ◀ 본 에이전트
```

4팩터 점수는 변경하지 않습니다. 후보 풀(Top 10 진입)은 정량 공식이 객관적으로 보장하므로 근거 없는 종목이 끼어들 수 없고, 본 에이전트는 그 안에서 "저평가 해소 가능성" 순으로만 재배열합니다. 결과(`ai_rank`)는 `ai_notes.json`에 commit되어 정적 서빙되므로, 그 시점 판단이 누구에게나 동일하게 재현됩니다 (정적 호스팅 원칙 유지).

## 8. 운영 예외 처리

| 시나리오 | 처리 |
|---|---|
| ai_notes 일부 누락 | 누락 종목은 quant_rank 위치 유지, 나머지만 재순위 |
| 모든 종목 rerank_score 동점 | quant_rank 순서 그대로 (정량 순위 = AI 순위) |
| ai_notes.json 쓰기 실패 | 이전 파일 유지, 운영자 알림 |
| ranker 출력 JSON 파싱 실패 | 재순위 미적용, quant_rank를 ai_rank로 폴백 |
